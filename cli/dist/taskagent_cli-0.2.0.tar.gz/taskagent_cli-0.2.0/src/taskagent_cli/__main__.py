from taskagent_cli.cli import run

if __name__ == "__main__":
    run()
